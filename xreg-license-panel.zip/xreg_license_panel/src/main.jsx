import React, { useState } from 'react';
import { createRoot } from 'react-dom/client';
import { ShieldCheck, KeyRound, LockKeyhole, Copy, Plus, Trash2, CheckCircle2, XCircle, MonitorSmartphone, LogOut } from 'lucide-react';
import './style.css';

const KEY_STORE = 'xreg-demo-licenses-v1';
const ADMIN_PIN = 'CHANGE-THIS-PIN'; // Change before using; this is only a demo admin gate.
const loadKeys = () => {
  try { return JSON.parse(localStorage.getItem(KEY_STORE) || '[]'); } catch { return []; }
};
const saveKeys = (keys) => localStorage.setItem(KEY_STORE, JSON.stringify(keys));
const makeKey = () => 'XREG-' + Array.from({length: 3}, () => Math.random().toString(36).slice(2, 6).toUpperCase()).join('-');
const normalise = (v) => v.trim().toUpperCase();
const formatKey = (v) => normalise(v).replace(/[^A-Z0-9-]/g, '').slice(0, 19);

function App() {
  const [key, setKey] = useState('');
  const [status, setStatus] = useState(null);
  const [keys, setKeys] = useState(loadKeys);
  const [adminOpen, setAdminOpen] = useState(false);
  const [pin, setPin] = useState('');
  const [authed, setAuthed] = useState(false);
  const [deviceId, setDeviceId] = useState(() => {
    let id = localStorage.getItem('xreg-device-id');
    if (!id) { id = 'DEV-' + crypto.randomUUID().slice(0, 8).toUpperCase(); localStorage.setItem('xreg-device-id', id); }
    return id;
  });

  const authenticate = (e) => {
    e.preventDefault();
    const submitted = normalise(key);
    if (!/^XREG-[A-Z0-9]{4}-[A-Z0-9]{4}-[A-Z0-9]{4}$/.test(submitted)) {
      setStatus({ok:false, text:'Enter a key in XREG-XXXX-XXXX-XXXX format.'}); return;
    }
    const record = keys.find(k => k.key === submitted);
    if (!record) { setStatus({ok:false, text:'License not found. Ask the panel administrator for a valid key.'}); return; }
    if (record.revoked) { setStatus({ok:false, text:'This license has been revoked.'}); return; }
    if (record.device && record.device !== deviceId) { setStatus({ok:false, text:'This license is already bound to another device.'}); return; }
    if (!record.device) {
      const updated = keys.map(k => k.key === submitted ? {...k, device:deviceId, boundAt:new Date().toISOString()} : k);
      setKeys(updated); saveKeys(updated);
    }
    setStatus({ok:true, text:'License authenticated on this device.'});
  };

  const loginAdmin = (e) => {
    e.preventDefault();
    if (pin === ADMIN_PIN) { setAuthed(true); setPin(''); }
    else setStatus({ok:false, text:'Admin PIN incorrect. Change ADMIN_PIN in src/main.jsx before use.'});
  };
  const createLicense = () => {
    let candidate = makeKey();
    while (keys.some(k => k.key === candidate)) candidate = makeKey();
    const updated = [{key:candidate, createdAt:new Date().toISOString(), device:null, revoked:false}, ...keys];
    setKeys(updated); saveKeys(updated);
  };
  const revoke = (target) => {
    const updated = keys.map(k => k.key === target ? {...k, revoked:!k.revoked} : k);
    setKeys(updated); saveKeys(updated);
  };
  const copyKey = async (value) => { try { await navigator.clipboard.writeText(value); setStatus({ok:true, text:'Key copied to clipboard.'}); } catch { setStatus({ok:false, text:'Clipboard unavailable; select and copy the key manually.'}); } };

  return <main className="shell">
    <header className="topbar">
      <div className="brand"><div className="brand-mark"><span>✦</span></div><div><div className="brand-name">XREG<span> / LICENSE</span></div><div className="brand-sub">SECURE ACCESS ENGINE</div></div></div>
      <button className="admin-toggle" onClick={() => {setAdminOpen(!adminOpen); setStatus(null);}}><LockKeyhole size={15}/><span>{adminOpen ? 'CLOSE ADMIN' : 'ADMIN'}</span></button>
    </header>

    <section className="hero">
      <div className="eyebrow"><span className="pulse"></span> LICENSE AUTHENTICATION <span className="eyebrow-right">SYSTEM / 01</span></div>
      <div className="logo-wrap"><div className="claw claw1"></div><div className="claw claw2"></div><div className="claw claw3"></div><div className="logo-text">XREG</div></div>
      <h1>ACCESS <span>CONTROL</span></h1>
      <p className="intro">Authenticate your license to access the engine.</p>
      <form onSubmit={authenticate} className="auth-form">
        <label htmlFor="license"><KeyRound size={15}/> LICENSE KEY</label>
        <input id="license" value={key} onChange={e => {setKey(formatKey(e.target.value)); setStatus(null);}} placeholder="XREG-XXXX-XXXX-XXXX" autoCapitalize="characters" autoComplete="off" spellCheck="false" />
        <button className="primary" type="submit"><ShieldCheck size={18}/> AUTHENTICATE <span>↗</span></button>
      </form>
      {status && <div className={`notice ${status.ok ? 'success':'error'}`}>{status.ok ? <CheckCircle2 size={17}/> : <XCircle size={17}/>}<span>{status.text}</span></div>}
      <div className="device"><MonitorSmartphone size={15}/><span>DEVICE ID</span><code>{deviceId}</code></div>
      <p className="fineprint">Each license can be bound to one device. This starter version stores data in this browser only; use a backend for real multi-user security.</p>
    </section>

    {adminOpen && <section className="admin-panel">
      <div className="admin-head"><div><div className="eyebrow">CONTROL CENTER</div><h2>License management</h2></div><span className="count">{keys.length} KEYS</span></div>
      {!authed ? <form className="admin-login" onSubmit={loginAdmin}><label htmlFor="pin">ADMIN PIN</label><input id="pin" type="password" value={pin} onChange={e=>setPin(e.target.value)} placeholder="Enter admin PIN"/><button className="primary" type="submit">UNLOCK ADMIN</button><small>Demo only: set ADMIN_PIN in src/main.jsx before use.</small></form> :
      <><div className="admin-actions"><button className="primary" onClick={createLicense}><Plus size={17}/> GENERATE LICENSE</button><button className="quiet" onClick={()=>setAuthed(false)}><LogOut size={15}/> LOCK</button></div>
      {keys.length === 0 ? <div className="empty">No licenses generated yet. Create your first license above.</div> :
      <div className="key-list">{keys.map(item=><div className="key-row" key={item.key}><div className="key-info"><code>{item.key}</code><small>{item.device ? `Bound: ${item.device}` : 'Not yet bound'} · {item.revoked ? 'REVOKED':'ACTIVE'}</small></div><button title="Copy key" className="icon-btn" onClick={()=>copyKey(item.key)}><Copy size={15}/></button><button title={item.revoked?'Restore key':'Revoke key'} className="icon-btn danger" onClick={()=>revoke(item.key)}><Trash2 size={15}/></button></div>)}</div>}
      <p className="fineprint">Admin keys and license records are stored locally in this browser. This is a prototype, not production security.</p></>}
    </section>}

    <footer><span>© 2026 XREG SYSTEMS</span><span><i></i> ENCRYPTED INTERFACE</span></footer>
  </main>;
}

createRoot(document.getElementById('root')).render(<App/>);
